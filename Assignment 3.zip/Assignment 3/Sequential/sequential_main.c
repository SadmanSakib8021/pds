#include<math.h>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>


typedef struct Point 
{
    double x;
    double y;
    
}Point;

double get_random(){
    double r = (double)rand()/RAND_MAX;

    if(rand() % 2 == 0){
        return r;
    }
    else{
        return (-1) * r;
    }
}

double distance(const Point* a, const Point* b){
    return sqrt((a->x - b->x)*(a->x - b->x)+(a->y - b->y)*(a->y - b->y));
}

double calculate_pi(int n){
    srand(time(NULL));

    int circle_count = 0;

    Point center = {0.f,0.f};
    double radius = 1.0f;

    for(int i=0; i<n; i++){
        Point p = {get_random(), get_random()};
        
        if(distance(&center,&p) <= radius){
            circle_count++;
        }
        
    }
    double approx_pi = 4.0f * ((double)circle_count/n);
    return approx_pi;
}


int main(){

    int n = 10000000;
    clock_t start = clock();
    double pi = calculate_pi(n);
    clock_t end = clock();

    printf("pi : %lf\n", pi);

    

    double cpu_time_used = (double)(end - start)/CLOCKS_PER_SEC;
    printf("time passed : %lf seconds\n",cpu_time_used);

    return 0;
}