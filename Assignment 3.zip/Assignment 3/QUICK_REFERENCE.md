# Quick Reference Guide - i5-1135G7 Optimized

## System Specs
- Intel i5-1135G7: **4 physical cores, 8 hardware threads**
- Optimized for parallel computation up to 4 workers

## Compilation
```bash
cd "/root/projects/Assignment 3"
make all
```

## Running Experiments

### Individual Runs
```bash
# Sequential (baseline)
./Build/serial

# Parallel with 2 workers (50% utilization)
mpirun --allow-run-as-root --use-hwthread-cpus -np 3 ./Build/parallel

# Parallel with 4 workers (optimal - matches physical cores)
mpirun --allow-run-as-root --use-hwthread-cpus -np 5 ./Build/parallel

# Parallel with 7 workers (near full thread utilization)
mpirun --allow-run-as-root --use-hwthread-cpus -np 8 ./Build/parallel

# Parallel spawn (dynamic worker creation)
cd Build
mpirun --allow-run-as-root --use-hwthread-cpus -np 1 ./master
cd ..
```

### All Experiments at Once
```bash
./run_experiments.sh
```

## Performance Summary

| Configuration | Time (s) | Speedup | Efficiency |
|--------------|----------|---------|------------|
| Sequential   | 0.800    | 1.00x   | 100%       |
| 2 workers    | 0.382    | 2.09x   | 104%       |
| 4 workers    | 0.276    | 2.90x   | 72%        |
| 7 workers    | 0.270    | 2.96x   | 42%        |
| Spawn (7)    | 1.163    | 0.69x   | -31%       |

## Recommended Configuration
**Use 4-5 workers (5 total processes) for best performance!**

## Key MPI Flags for i5-1135G7
- `--allow-run-as-root`: Required when running as root user
- `--use-hwthread-cpus`: Enables use of all 8 hardware threads (not just 4 physical cores)
- `-np N`: Number of processes to launch

## Important Notes
1. **Physical cores (4) give best efficiency** - 2.90x speedup with 72% efficiency
2. **Hyper-Threading provides diminishing returns** - only 2% improvement from 4 to 7 workers
3. **Spawn overhead is significant** - 45% slower than sequential for this workload
4. Results may vary slightly due to random number generation
