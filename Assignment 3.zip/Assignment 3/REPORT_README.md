# LaTeX Report - Summary

## Report Generated Successfully! ✅

**File**: `report.pdf` (247 KB, 9 pages)

## What's Included in the Report

### 1. **Comprehensive Analysis** with Three Integrated Plots:
   - **Execution Time Plot** - Shows performance across configurations
   - **Speedup Plot** - Compares actual vs ideal speedup
   - **Accuracy Plot** - Demonstrates precision across implementations

### 2. **Detailed Explanations for Each Plot**:

#### **Why Execution Time Shows This Pattern:**
- Steep decline from sequential to 2 workers (near-ideal parallelization)
- Continued improvement to 4 workers (matches physical cores)
- Marginal gains beyond 4 workers (hyperthreading limitations)
- Spawn version degradation (45% overhead from process creation)

#### **Why Speedup Deviates from Ideal:**
- **Amdahl's Law limitations** - Serial fraction in aggregation
- **Communication overhead growth** - Linear with worker count
- **Hyperthreading diminishing returns** - Shared execution resources
- **Memory bandwidth saturation** - All threads compete for access
- **Spawn overhead** - 0.36s initialization dominates short workload

#### **Why Accuracy Pattern Appears:**
- **Statistical variance** - Monte Carlo inherent randomness
- **Sample size effects** - Error ∝ 1/√n
- **RNG quality** - Different execution paths produce different sequences
- **Worker count impact** - Fewer samples per worker increases variance
- **All errors acceptable** - Within 0.002 (0.05% relative error)

### 3. **Why Plots Are Accurate in Context:**
- Execution time reflects real hardware constraints (i5-1135G7)
- Speedup matches theoretical predictions (Amdahl's Law)
- Accuracy demonstrates implementation correctness
- WSL environment overhead accounted for

### 4. **Why Performance Isn't Perfect:**
- Communication overhead (MPI message passing)
- Memory bandwidth limitations (~50 GB/s shared)
- Cache coherency costs (L1/L2/L3 management)
- Operating system overhead (WSL virtualization)
- Hyperthreading constraints (shared ALU/FPU)

## Report Sections

1. **Abstract** - Overview of parallel Monte Carlo analysis
2. **Introduction** - Monte Carlo methods and parallelization
3. **System Configuration** - Hardware and software specs
4. **Implementation Approaches** - Three implementations explained
5. **Experimental Results** - Data tables and plots
6. **Analysis and Discussion** - Deep dive into each plot pattern
7. **Conclusions and Recommendations** - Key findings and best practices
8. **Future Work** - Potential improvements

## Key Insights from the Report

### Optimal Configuration:
- **4 workers** (matching physical cores) = **2.90× speedup**
- Best price/performance ratio with 72% parallel efficiency

### Hyperthreading Reality:
- Beyond 4 workers provides only **2% improvement**
- Compute-intensive workloads don't benefit from HT

### Spawn Overhead:
- **45% slower** than sequential execution
- **0.36s fixed overhead** for process creation
- Not suitable for short-running computations

### Accuracy Maintained:
- All implementations: error < 0.002
- Parallel aggregation preserves correctness
- Statistical variance is expected and acceptable

## Mathematical Foundations Included

The report includes proper equations for:
- **Amdahl's Law**: S(n) = 1 / ((1-p) + p/n)
- **Spawn overhead**: T_spawn = T_init + T_compute + T_comm
- **Monte Carlo error**: σ ≈ σ_f / √N
- **Parallel efficiency**: E(n) = S(n)/n × 100%

## How to View the Report

```bash
# Open the PDF
cd "/root/projects/Assignment 3"
xdg-open report.pdf  # Or use any PDF viewer
```

## Files Created

```
Assignment 3/
├── report.tex      # LaTeX source (comprehensive, well-documented)
├── report.pdf      # Final PDF report (9 pages, 247 KB)
├── report.aux      # LaTeX auxiliary file
├── report.log      # Compilation log
└── report.out      # Hyperref outline file
```

## LaTeX Features Used

- Professional article document class
- High-quality plot integration (PNG images)
- Mathematical equations (amsmath)
- Hyperlinked references and citations
- Proper figure and table numbering
- Section hierarchy and structure
- Bibliography-ready (future work)

The report provides publication-quality documentation of your parallel computing experiments! 🎓
