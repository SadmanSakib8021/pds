#!/bin/bash

# Run experiments and collect results
# Optimized for Intel i5-1135G7: 4 cores, 8 threads

cd "/root/projects/Assignment 3"

echo "============================================"
echo "System: Intel i5-1135G7 (4 cores, 8 threads)"
echo "Testing with 2, 4, and 7 workers"
echo "============================================"
echo ""

echo "===== Running Sequential Version (Baseline) ====="
./Build/serial
echo ""

echo "===== Running Parallel Version with 3 processes (1 master + 2 workers) ====="
echo "[Using 2 workers - 50% of threads]"
mpirun --allow-run-as-root --use-hwthread-cpus -np 3 ./Build/parallel
echo ""

echo "===== Running Parallel Version with 5 processes (1 master + 4 workers) ====="
echo "[Using 4 workers - matches physical cores]"
mpirun --allow-run-as-root --use-hwthread-cpus -np 5 ./Build/parallel
echo ""

echo "===== Running Parallel Version with 8 processes (1 master + 7 workers) ====="
echo "[Using 7 workers - near full thread utilization]"
mpirun --allow-run-as-root --use-hwthread-cpus -np 8 ./Build/parallel
echo ""

echo "===== Running Parallel Spawn Version (1 master spawns 7 workers) ====="
echo "[Dynamic spawn with 7 workers - testing MPI_Comm_spawn overhead]"
cd Build
mpirun --allow-run-as-root --use-hwthread-cpus -np 1 ./master
cd ..
echo ""

echo "============================================"
echo "All experiments completed!"
echo "Results saved for 2, 4, and 7 worker configurations"
echo "============================================"
