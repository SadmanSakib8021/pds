#include <math.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <mpi.h>

MPI_Status STATUS;

typedef struct Point
{
    double x;
    double y;

} Point;

double get_random()
{
    double r = (double)rand() / RAND_MAX;

    if (rand() % 2 == 0)
    {
        return r;
    }
    else
    {
        return (-1) * r;
    }
}

double distance(const Point *a, const Point *b)
{
    return sqrt((a->x - b->x) * (a->x - b->x) + (a->y - b->y) * (a->y - b->y));
}

double calculate_pi(int n)
{
    srand(time(NULL));

    int circle_count = 0;

    Point center = {0.f, 0.f};
    double radius = 1.0f;

    for (int i = 0; i < n; i++)
    {
        Point p = {get_random(), get_random()};

        if (distance(&center, &p) <= radius)
        {
            circle_count++;
        }
    }
    double approx_pi = 4.0f * ((double)circle_count / n);
    return approx_pi;
}

int main()
{

    MPI_Init(NULL, NULL);

    MPI_Comm parentcomm;
    MPI_Comm_get_parent(&parentcomm);

    if (parentcomm == MPI_COMM_NULL)
    {
        printf("No parent! Exiting.\n");
        MPI_Finalize();
        return 0;
    }

    int rank; // this is the rank from the worker's world
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    int nPoints = 0;

    MPI_Recv(
        &nPoints,
        1,
        MPI_INT,
        0,
        0,
        parentcomm,
        &STATUS);

    printf("[SLAVE|rank %d]received nPoints= %d from masters\n", rank, nPoints);

    double _pi = calculate_pi(nPoints);

    MPI_Send(
        &_pi,
        1,
        MPI_DOUBLE,
        0,
        0,
        parentcomm);

    printf("[SLAVE|rank %d]sending local pi= %lf to master\n", rank, _pi);

    MPI_Finalize();

    return 0;
}