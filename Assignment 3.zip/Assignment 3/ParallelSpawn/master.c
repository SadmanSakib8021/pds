#include <math.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <mpi.h>

MPI_Status STATUS;

typedef struct Point
{
    double x;
    double y;

} Point;

double get_random()
{
    double r = (double)rand() / RAND_MAX;

    if (rand() % 2 == 0)
    {
        return r;
    }
    else
    {
        return (-1) * r;
    }
}

double distance(const Point *a, const Point *b)
{
    return sqrt((a->x - b->x) * (a->x - b->x) + (a->y - b->y) * (a->y - b->y));
}

double calculate_pi(int n)
{
    srand(time(NULL));

    int circle_count = 0;

    Point center = {0.f, 0.f};
    double radius = 1.0f;

    for (int i = 0; i < n; i++)
    {
        Point p = {get_random(), get_random()};

        if (distance(&center, &p) <= radius)
        {
            circle_count++;
        }
    }
    double approx_pi = 4.0f * ((double)circle_count / n);
    return approx_pi;
}

int main()
{

    clock_t start = clock();

    MPI_Init(NULL, NULL);

    int n = 10000000;

    // Using 7 workers to match i5-1135G7 thread count (8 threads - 1 master = 7 workers)
    int num_workers = 7;
    MPI_Comm intercom;

    MPI_Comm_spawn(
        "worker",
        MPI_ARGV_NULL,
        num_workers,
        MPI_INFO_NULL,
        0,
        MPI_COMM_WORLD,
        &intercom,
        MPI_ERRCODES_IGNORE);

    int size, rank;
    MPI_Comm_size(MPI_COMM_WORLD, &size); // this will return 1
    printf("[MASTER|rank %d]size %d\n",rank, size);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    double pi = 0.f;

    int nPoints = 0;

    for (int dest = 0; dest < num_workers; dest++)
    {
        nPoints = n / size;
        MPI_Send(
            &nPoints,
            1,
            MPI_INT,
            dest,
            0,
            intercom);

        printf("[MASTER|rank %d]sending nPoints= %d to dest= %d\n", rank, nPoints, dest);
    }

    double _pi = calculate_pi(nPoints);

    for (int sender = 0; sender < num_workers; sender++)
    {
        double recv_pi;
        MPI_Recv(
            &recv_pi,
            1,
            MPI_DOUBLE,
            sender,
            0,
            intercom,
            &STATUS);

        printf("[MASTER|rank %d]received local pi= %lf from sender= %d\n", rank, recv_pi, sender);

        pi += recv_pi;
    }

    pi += _pi;

    pi = pi / (1 + num_workers);

    MPI_Finalize();

    clock_t end = clock();

    printf("pi : %lf\n", pi);

    double cpu_time_used = (double)(end - start) / CLOCKS_PER_SEC;
    printf("time passed : %lf seconds\n", cpu_time_used);

    return 0;
}