#include <math.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <mpi.h>

MPI_Status STATUS;

typedef struct Point
{
    double x;
    double y;

} Point;

double get_random()
{
    double r = (double)rand() / RAND_MAX;

    if (rand() % 2 == 0)
    {
        return r;
    }
    else
    {
        return (-1) * r;
    }
}

double distance(const Point *a, const Point *b)
{
    return sqrt((a->x - b->x) * (a->x - b->x) + (a->y - b->y) * (a->y - b->y));
}

double calculate_pi(int n)
{
    srand(time(NULL));

    int circle_count = 0;

    Point center = {0.f, 0.f};
    double radius = 1.0f;

    for (int i = 0; i < n; i++)
    {
        Point p = {get_random(), get_random()};

        if (distance(&center, &p) <= radius)
        {
            circle_count++;
        }
    }
    double approx_pi = 4.0f * ((double)circle_count / n);
    return approx_pi;
}

int main()
{

    clock_t start = clock();

    MPI_Init(NULL, NULL);

    int n = 10000000;

    int size, rank;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    double pi = 0.f;

    int nPoints = 0;
    if (rank == 0)
    { // master

        for (int dest = 1; dest < size; dest++)
        {
            nPoints = n / size;
            MPI_Send(
                &nPoints,
                1,
                MPI_INT,
                dest,
                0,
                MPI_COMM_WORLD);

            printf("[rank %d]sending nPoints= %d to dest= %d\n", rank, nPoints, dest);
        }
    }
    else
    { // slaves
        nPoints = n % size == 0? (n / size) : (n % size);
        MPI_Recv(
            &nPoints,
            1,
            MPI_INT,
            0,
            0,
            MPI_COMM_WORLD,
            &STATUS);

        printf("[rank %d]received nPoints= %d from masters\n", rank, nPoints);
    }

    double _pi = calculate_pi(nPoints);


    if (rank != 0)
    {
        MPI_Send(
            &_pi,
            1,
            MPI_DOUBLE,
            0,
            0,
            MPI_COMM_WORLD);

        printf("[rank %d]sending local pi= %lf to master\n", rank, _pi);
    }
    else
    {

        for (int sender = 1; sender < size; sender++)
        {
            double recv_pi;
            MPI_Recv(
                &recv_pi,
                1,
                MPI_DOUBLE,
                sender,
                0,
                MPI_COMM_WORLD,
                &STATUS);
            
            printf("[rank %d]received local pi= %lf from sender= %d\n", rank, recv_pi, sender);

            pi += recv_pi;
        }

        pi += _pi;
    }

    pi = pi / size;

    MPI_Finalize();

    clock_t end = clock();

    if(rank == 0){
        printf("pi : %lf\n", pi);

        double cpu_time_used = (double)(end - start) / CLOCKS_PER_SEC;
        printf("time passed : %lf seconds\n", cpu_time_used);
    }
    

    return 0;
}