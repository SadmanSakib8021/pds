# Assignment 3 - Monte Carlo Pi Calculation Results

## System Information
- **Processor**: 11th Gen Intel(R) Core(TM) i5-1135G7 @ 2.40GHz (2.42 GHz)
- **Physical Cores**: 4 cores
- **Logical Threads**: 8 threads (with Hyper-Threading)
- **RAM**: 16.0 GB (15.8 GB usable)
- **Environment**: Ubuntu WSL
- **MPI Configuration**: OpenMPI with `--use-hwthread-cpus` flag for thread utilization

## Project Overview
This project implements Monte Carlo simulation to estimate the value of π using:
1. **Sequential Implementation**: Single-threaded computation
2. **Parallel MPI Implementation**: Master-worker with MPI_Init
3. **Parallel Spawn Implementation**: Master spawns workers dynamically using MPI_Comm_spawn

## Experimental Results

### Sequential Version (Baseline)
- **Execution Time**: 0.800157 seconds
- **Estimated π**: 3.141119
- **Error**: 0.000474 (from actual π = 3.141593)

### Parallel Version (MPI Normal)

| Workers | Total Processes | Execution Time (s) | Estimated π | Error | Speedup |
|---------|----------------|-------------------|-------------|-------|---------|
| 2       | 3              | 0.382329         | 3.141149    | 0.000444 | 2.09x |
| 4       | 5              | 0.276152         | 3.139948    | 0.001645 | 2.90x |
| 7       | 8              | 0.270152         | 3.142464    | 0.000871 | 2.96x |

### Parallel Spawn Version (MPI_Comm_spawn)

| Workers | Total Processes | Execution Time (s) | Estimated π | Error | Speedup |
|---------|----------------|-------------------|-------------|-------|---------|
| 7       | 8              | 1.162615         | 3.141437    | 0.000156 | 0.69x |

**Note**: The parallel spawn version includes the overhead of spawning processes dynamically, which significantly impacts performance. The master spawns 7 workers at runtime using MPI_Comm_spawn.

## Analysis

### Performance Observations

1. **Parallel Speedup**: 
   - With 2 workers: **2.09x speedup** (near-ideal for 2 threads)
   - With 4 workers: **2.90x speedup** (excellent, matches physical cores)
   - With 7 workers: **2.96x speedup** (slight improvement, approaching hardware limit)

2. **Parallel Spawn Overhead**:
   - The spawn version is **1.45x slower** than sequential
   - Process spawning overhead (~0.36 seconds) dominates the computation time
   - Not suitable for compute-intensive tasks with short execution times
   - Dynamic spawning adds significant latency compared to pre-initialized MPI processes

3. **Accuracy**:
   - All implementations maintain excellent accuracy (error < 0.002)
   - Parallel version with 4 workers shows highest error (0.001645) due to fewer samples per worker
   - Spawn version has lowest error (0.000156) due to larger sample size per worker
   - Random number generation patterns affect accuracy slightly

### Key Findings

1. **Optimal Configuration**: 
   - **4 workers (matches physical cores)** provides best price/performance ratio (2.90x speedup)
   - Execution time: 0.276 seconds vs 0.800 seconds sequential

2. **Scalability Analysis**:
   - **2 to 4 workers**: Strong scaling (2.09x → 2.90x, 38% improvement)
   - **4 to 7 workers**: Diminishing returns (2.90x → 2.96x, only 2% improvement)
   - Beyond 4 workers: Limited by Hyper-Threading overhead and communication costs
   - Amdahl's Law evident: parallel efficiency drops from 104% (2 workers) to 42% (7 workers)

3. **Hyper-Threading Impact**:
   - Going from 4 cores to 8 threads provides only 6% additional speedup
   - Memory bandwidth and cache contention limit HT benefits for compute-intensive workloads
   - For this workload, physical cores matter more than logical threads

4. **MPI_Comm_spawn Overhead**:
   - Dynamic spawning adds ~0.36 seconds fixed overhead
   - This overhead is **45%** of sequential runtime
   - Pre-initialized processes (standard MPI) are 4.3x faster than spawn approach
   - Only beneficial when: (a) worker count unknown at launch, (b) long-running computations

5. **WSL Performance**: 
   - Results reasonable considering WSL virtualization overhead
   - Near-linear scaling up to physical core count validates implementation

## Visualizations

Three plots have been generated in the `plot/` directory:
1. **Execution_Time.png**: Comparison of execution times
2. **Speedup.png**: Speedup vs ideal speedup
3. **Accuracy.png**: Absolute error in π estimation

## Files Generated

```
Assignment 3/
├── Build/
│   ├── serial          # Sequential executable
│   ├── parallel        # Parallel MPI executable
│   ├── master          # Spawn master executable
│   └── worker          # Spawn worker executable
├── plot/
│   ├── Execution_Time.png
│   ├── Speedup.png
│   ├── Accuracy.png
│   └── plot.ipynb      # Updated with current results
├── venv/              # Python virtual environment
└── run_experiments.sh # Script to run all experiments
```

## Compilation Instructions

```bash
# Compile all programs
make all

# Or individually:
make serial    # gcc
make parallel  # mpicc
make spawn     # mpicc
```

## Running Instructions

```bash
# Sequential
./Build/serial

# Parallel with N processes
mpirun --allow-run-as-root --oversubscribe -np N ./Build/parallel

# Parallel Spawn
cd Build && mpirun --allow-run-as-root --oversubscribe -np 1 ./master

# Run all experiments
./run_experiments.sh
```

## Recommendations

### For i5-1135G7 (4-core, 8-thread):
1. **Use 4-5 workers** for optimal parallel performance (2.90x speedup)
2. **Avoid spawn approach** for short-running computations (45% overhead penalty)
3. **Pre-initialize MPI processes** rather than dynamic spawning
4. **Don't over-subscribe beyond 5 processes** - minimal gains with 7+ workers

### General Insights:
- Physical core count is the sweet spot for compute-intensive parallel workloads
- Hyper-Threading provides <10% benefit for Monte Carlo simulations
- Communication overhead becomes significant beyond physical core count
- Dynamic process spawning best suited for long-running jobs or adaptive workloads

## Conclusion

The MPI parallel implementation shows **excellent performance gains** (2.9x speedup) when configured for the physical core count (4 workers) on the i5-1135G7. The parallel spawn approach demonstrates the significant overhead of dynamic process creation (~45% of runtime), making it unsuitable for short-duration workloads like this Monte Carlo simulation.

**Key Takeaway**: For production use on 4-core/8-thread CPUs, use the standard MPI approach with 4-5 pre-allocated processes for optimal performance. The spawn approach should only be considered for scenarios requiring dynamic worker allocation or long-running computations where the spawn overhead becomes negligible.
